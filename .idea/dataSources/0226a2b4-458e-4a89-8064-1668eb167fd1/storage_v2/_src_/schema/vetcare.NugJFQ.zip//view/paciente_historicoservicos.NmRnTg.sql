create definer = root@localhost view paciente_historicoservicos as
select `s`.`iDServico`        AS `iDServico`,
       `p`.`iDPaciente`       AS `iDPaciente`,
       `p`.`nome`             AS `nomePaciente`,
       `s`.`descricao`        AS `descricao`,
       `s`.`dataHoraAgendada` AS `dataHoraAgendada`,
       `s`.`estado`           AS `estado`,
       `s`.`localidade`       AS `localidade`,
       `s`.`iDUtilizador`     AS `responsavel`
from (`vetcare`.`servicomedicoagendamento` `s` join `vetcare`.`paciente` `p` on ((`s`.`iDPaciente` = `p`.`iDPaciente`)))
order by `p`.`iDPaciente`, `s`.`dataHoraAgendada`;

