create definer = root@localhost trigger tg_clinica_ultimo_horario
    before delete
    on horario
    for each row
BEGIN
    IF (SELECT COUNT(*) FROM Horario WHERE localidade = OLD.localidade) = 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Não é permitido eliminar o único horário da clínica.';
    END IF;
END;

