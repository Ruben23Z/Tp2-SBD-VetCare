create definer = root@localhost view consulta_detalhada as
select `c`.`iDServico`        AS `iDServico`,
       `s`.`dataHoraAgendada` AS `dataHoraAgendada`,
       `p`.`nome`             AS `nomePaciente`,
       `c`.`diagnostico`      AS `diagnostico`,
       `c`.`sintomas`         AS `sintomas`,
       `c`.`pesoMedido`       AS `pesoMedido`,
       `c`.`temp`             AS `temp`,
       `c`.`freqCardiaca`     AS `freqCardiaca`,
       `c`.`freqRespiratoria` AS `freqRespiratoria`,
       `c`.`proxConsulta`     AS `proxConsulta`,
       `c`.`notas`            AS `notas`
from ((`vetcare`.`consulta` `c` join `vetcare`.`servicomedicoagendamento` `s`
       on ((`c`.`iDServico` = `s`.`iDServico`))) join `vetcare`.`paciente` `p`
      on ((`s`.`iDPaciente` = `p`.`iDPaciente`)));

