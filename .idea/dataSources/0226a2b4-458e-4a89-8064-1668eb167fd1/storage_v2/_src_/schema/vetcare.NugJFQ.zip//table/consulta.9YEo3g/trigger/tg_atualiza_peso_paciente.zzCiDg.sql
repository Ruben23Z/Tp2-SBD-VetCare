create definer = root@localhost trigger tg_atualiza_peso_paciente
    after insert
    on consulta
    for each row
BEGIN
    UPDATE Paciente SET pesoAtual = NEW.pesoMedido
    WHERE iDPaciente = (SELECT iDPaciente FROM ServicoMedicoAgendamento WHERE iDServico = NEW.iDServico);
END;

