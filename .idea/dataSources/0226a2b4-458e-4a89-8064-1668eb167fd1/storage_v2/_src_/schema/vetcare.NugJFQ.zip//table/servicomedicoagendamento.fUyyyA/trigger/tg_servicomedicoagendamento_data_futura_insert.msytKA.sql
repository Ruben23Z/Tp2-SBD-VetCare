create definer = root@localhost trigger tg_ServicoMedicoAgendamento_data_futura_insert
    before insert
    on servicomedicoagendamento
    for each row
BEGIN
    IF NEW.dataHoraAgendada <= NOW() THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A data/hora agendada deve ser futura (INSERT).';
    END IF;
END;

