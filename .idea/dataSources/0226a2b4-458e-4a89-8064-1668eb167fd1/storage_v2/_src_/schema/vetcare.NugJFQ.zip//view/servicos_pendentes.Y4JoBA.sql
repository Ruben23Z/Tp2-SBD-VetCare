create definer = root@localhost view servicos_pendentes as
select `vetcare`.`servicomedicoagendamento`.`iDServico`                 AS `iDServico`,
       `vetcare`.`servicomedicoagendamento`.`descricao`                 AS `descricao`,
       `vetcare`.`servicomedicoagendamento`.`dataHoraInicio`            AS `dataHoraInicio`,
       `vetcare`.`servicomedicoagendamento`.`dataHoraAgendada`          AS `dataHoraAgendada`,
       `vetcare`.`servicomedicoagendamento`.`estado`                    AS `estado`,
       `vetcare`.`servicomedicoagendamento`.`custoCancelamento`         AS `custoCancelamento`,
       `vetcare`.`servicomedicoagendamento`.`agendatario`               AS `agendatario`,
       `vetcare`.`servicomedicoagendamento`.`iDPaciente`                AS `iDPaciente`,
       `vetcare`.`servicomedicoagendamento`.`iDUtilizador`              AS `iDUtilizador`,
       `vetcare`.`servicomedicoagendamento`.`localidade`                AS `localidade`,
       `vetcare`.`servicomedicoagendamento`.`fichaIniciadaRececionista` AS `fichaIniciadaRececionista`
from `vetcare`.`servicomedicoagendamento`
where (`vetcare`.`servicomedicoagendamento`.`estado` = 'pendente')
order by `vetcare`.`servicomedicoagendamento`.`dataHoraAgendada`;

