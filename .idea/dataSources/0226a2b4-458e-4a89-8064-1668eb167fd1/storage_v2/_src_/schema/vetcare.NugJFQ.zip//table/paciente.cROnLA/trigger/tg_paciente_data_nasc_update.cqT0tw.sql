create definer = root@localhost trigger tg_paciente_data_nasc_update
    before update
    on paciente
    for each row
BEGIN
    IF NEW.dataNascimento > CURDATE() THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Data de nascimento não pode ser futura.';
    END IF;

    IF NEW.dataObito IS NULL THEN
        SET NEW.idade = TIMESTAMPDIFF(YEAR, NEW.dataNascimento, CURDATE());
    ELSE
        SET NEW.idade = TIMESTAMPDIFF(YEAR, NEW.dataNascimento, NEW.dataObito);
    END IF;
END;

