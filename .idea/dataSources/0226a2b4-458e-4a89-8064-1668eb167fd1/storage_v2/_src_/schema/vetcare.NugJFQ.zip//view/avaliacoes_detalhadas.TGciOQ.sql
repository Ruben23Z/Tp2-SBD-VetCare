create definer = root@localhost view avaliacoes_detalhadas as
select `r`.`iDavaliacao`   AS `iDavaliacao`,
       `r`.`dataavaliacao` AS `dataavaliacao`,
       `r`.`avaliacao`     AS `avaliacao`,
       `r`.`comentario`    AS `comentario`,
       `c`.`nome`          AS `nomeCliente`,
       `s`.`descricao`     AS `servico`,
       `p`.`nome`          AS `paciente`
from (((`vetcare`.`requesita` `r` join `vetcare`.`cliente` `c`
        on ((`r`.`NIF` = `c`.`NIF`))) join `vetcare`.`servicomedicoagendamento` `s`
       on ((`r`.`iDServico` = `s`.`iDServico`))) join `vetcare`.`paciente` `p`
      on ((`s`.`iDPaciente` = `p`.`iDPaciente`)));

