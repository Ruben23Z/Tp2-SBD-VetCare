create definer = root@localhost view exames_completos as
select `e`.`iDServico`         AS `iDServico`,
       `p`.`nome`              AS `nomePaciente`,
       `e`.`observacaoTecnica` AS `observacaoTecnica`,
       `e`.`dataHoraFim`       AS `dataHoraFim`,
       `e`.`duracao`           AS `duracao`,
       (case
            when (`r`.`iDServico` is not null) then 'Radiografia'
            when (`ec`.`iDServico` is not null) then 'Ecografia'
            when (`ac`.`iDServico` is not null) then 'Análise Clínica'
            else 'Outro' end)  AS `tipoExame`,
       `r`.`parteCorporal`     AS `parteCorporal`,
       `ec`.`categoriaEco`     AS `categoriaEco`,
       `ec`.`zona`             AS `zona`,
       `ac`.`tipoAnalise`      AS `tipoAnalise`,
       `ac`.`resultadoAnalise` AS `resultadoAnalise`
from (((((`vetcare`.`exame` `e` join `vetcare`.`servicomedicoagendamento` `s`
          on ((`e`.`iDServico` = `s`.`iDServico`))) join `vetcare`.`paciente` `p`
         on ((`s`.`iDPaciente` = `p`.`iDPaciente`))) left join `vetcare`.`radiografia` `r`
        on ((`e`.`iDServico` = `r`.`iDServico`))) left join `vetcare`.`ecografia` `ec`
       on ((`e`.`iDServico` = `ec`.`iDServico`))) left join `vetcare`.`analiseclinica` `ac`
      on ((`e`.`iDServico` = `ac`.`iDServico`)));

