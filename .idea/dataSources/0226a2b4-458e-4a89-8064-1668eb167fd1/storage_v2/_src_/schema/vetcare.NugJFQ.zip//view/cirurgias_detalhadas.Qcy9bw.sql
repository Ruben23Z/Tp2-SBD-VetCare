create definer = root@localhost view cirurgias_detalhadas as
select `c`.`iDServico`                                                AS `iDServico`,
       `p`.`nome`                                                     AS `nomePaciente`,
       `c`.`tipoCirurgia`                                             AS `tipoCirurgia`,
       `c`.`anestesia`                                                AS `anestesia`,
       `c`.`notas`                                                    AS `notas`,
       `a`.`dataHoraInicio`                                           AS `dataHoraInicio`,
       `c`.`dataHoraFim`                                              AS `dataHoraFim`,
       timestampdiff(MINUTE, `a`.`dataHoraInicio`, `c`.`dataHoraFim`) AS `duracaoMinutos`
from ((`vetcare`.`cirurgia` `c` join `vetcare`.`servicomedicoagendamento` `a`
       on ((`c`.`iDServico` = `a`.`iDServico`))) join `vetcare`.`paciente` `p`
      on ((`a`.`iDPaciente` = `p`.`iDPaciente`)));

