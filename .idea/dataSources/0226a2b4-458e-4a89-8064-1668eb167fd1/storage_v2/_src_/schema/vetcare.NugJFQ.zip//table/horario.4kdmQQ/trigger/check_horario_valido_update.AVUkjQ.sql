create definer = root@localhost trigger check_horario_valido_update
    before update
    on horario
    for each row
BEGIN
    IF NEW.horaFecho <= NEW.horaAbertura THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'horaFecho deve ser maior que horaAbertura (UPDATE).';
    END IF;
END;

