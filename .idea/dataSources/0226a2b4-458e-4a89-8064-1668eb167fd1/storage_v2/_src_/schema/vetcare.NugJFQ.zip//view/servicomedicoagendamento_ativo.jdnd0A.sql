create definer = root@localhost view servicomedicoagendamento_ativo as
select `a`.`iDServico`        AS `iDServico`,
       `a`.`descricao`        AS `descricao`,
       `a`.`dataHoraAgendada` AS `dataHoraAgendada`,
       `a`.`estado`           AS `estado`,
       `a`.`localidade`       AS `localidade`,
       `a`.`iDPaciente`       AS `iDPaciente`,
       `p`.`nome`             AS `nomePaciente`,
       `a`.`iDUtilizador`     AS `iDUtilizador`
from (`vetcare`.`servicomedicoagendamento` `a` join `vetcare`.`paciente` `p` on ((`a`.`iDPaciente` = `p`.`iDPaciente`)))
where (`a`.`estado` = 'ativo');

