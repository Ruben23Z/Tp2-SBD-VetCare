create definer = root@localhost trigger tg_ServicoMedicoAgendamento_data_futura_update
    before update
    on servicomedicoagendamento
    for each row
BEGIN
    IF NEW.dataHoraAgendada <= NOW() THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A data/hora agendada deve ser futura (UPDATE).';
    END IF;
END;

