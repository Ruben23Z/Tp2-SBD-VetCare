create definer = root@localhost trigger tg_progenitor_mais_velho
    before insert
    on paciente_paciente
    for each row
BEGIN
    DECLARE dataFilho DATE;
    DECLARE dataProgenitor DATE;
    SELECT dataNascimento INTO dataFilho FROM Paciente WHERE iDPaciente = NEW.iDPaciente_Filho;
    SELECT dataNascimento INTO dataProgenitor FROM Paciente WHERE iDPaciente = NEW.iDPaciente_Progenitor;
    IF dataProgenitor >= dataFilho THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'O progenitor deve ser mais velho que o filho.';
    END IF;
END;

