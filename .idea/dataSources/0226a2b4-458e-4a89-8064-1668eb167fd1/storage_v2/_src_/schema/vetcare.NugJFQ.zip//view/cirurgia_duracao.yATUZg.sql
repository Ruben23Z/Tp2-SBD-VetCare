create definer = root@localhost view cirurgia_duracao as
select `c`.`iDServico`                                                AS `iDServico`,
       `c`.`tipoCirurgia`                                             AS `tipoCirurgia`,
       `c`.`anestesia`                                                AS `anestesia`,
       `c`.`notas`                                                    AS `notas`,
       `c`.`dataHoraFim`                                              AS `dataHoraFim`,
       `a`.`dataHoraInicio`                                           AS `dataHoraInicio`,
       timestampdiff(MINUTE, `a`.`dataHoraInicio`, `c`.`dataHoraFim`) AS `Duracao`
from (`vetcare`.`cirurgia` `c` join `vetcare`.`servicomedicoagendamento` `a` on ((`c`.`iDServico` = `a`.`iDServico`)));

