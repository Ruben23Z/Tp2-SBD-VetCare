create definer = root@localhost trigger tg_exclusivo_cirurgia
    after insert
    on cirurgia
    for each row
BEGIN
    IF EXISTS (SELECT 1 FROM Consulta WHERE iDServico = NEW.iDServico)
    OR EXISTS (SELECT 1 FROM Vacinacao WHERE iDServico = NEW.iDServico)
    OR EXISTS (SELECT 1 FROM Desparasitacao WHERE iDServico = NEW.iDServico)
    OR EXISTS (SELECT 1 FROM TratamentoTerapeutico WHERE iDServico = NEW.iDServico)
    OR EXISTS (SELECT 1 FROM Exame WHERE iDServico = NEW.iDServico) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Um serviço não pode pertencer a duas especializações.';
    END IF;
END;

