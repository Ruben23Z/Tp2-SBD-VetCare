create definer = root@localhost trigger tg_calc_duracao_exame
    before insert
    on exame
    for each row
BEGIN
    DECLARE inicio DATETIME;
    SELECT dataHoraInicio INTO inicio FROM ServicoMedicoAgendamento WHERE iDServico = NEW.iDServico;
    SET NEW.duracao = TIMESTAMPDIFF(MINUTE, inicio, NEW.dataHoraFim);
END;

