create definer = root@localhost trigger check_horario_valido
    before insert
    on horario
    for each row
BEGIN
    IF NEW.horaFecho <= NEW.horaAbertura THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'horaFecho deve ser maior que horaAbertura (INSERT).';
    END IF;
END;

