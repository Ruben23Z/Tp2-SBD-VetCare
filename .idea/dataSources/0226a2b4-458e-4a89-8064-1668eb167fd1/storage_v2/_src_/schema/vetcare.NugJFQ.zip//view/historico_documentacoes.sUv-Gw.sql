create definer = root@localhost view historico_documentacoes as
select `d`.`iDServico`        AS `iDServico`,
       `s`.`dataHoraAgendada` AS `dataHoraAgendada`,
       `s`.`descricao`        AS `servico`,
       `p`.`nome`             AS `nomePaciente`,
       `c`.`nome`             AS `nomeCliente`,
       `c`.`NIF`              AS `NIF`,
       `d`.`diagnostico`      AS `diagnostico`,
       `d`.`prescricoes`      AS `prescricoes`,
       `d`.`resultados`       AS `resultados`
from (((`vetcare`.`documenta` `d` join `vetcare`.`servicomedicoagendamento` `s`
        on ((`d`.`iDServico` = `s`.`iDServico`))) join `vetcare`.`paciente` `p`
       on ((`s`.`iDPaciente` = `p`.`iDPaciente`))) join `vetcare`.`cliente` `c` on ((`p`.`NIF` = `c`.`NIF`)))
order by `s`.`dataHoraAgendada` desc;

