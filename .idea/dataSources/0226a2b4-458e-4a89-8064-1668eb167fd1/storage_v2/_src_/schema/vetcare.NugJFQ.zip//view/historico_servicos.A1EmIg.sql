create definer = root@localhost view historico_servicos as
select `s`.`iDServico`                AS `iDServico`,
       `s`.`descricao`                AS `descricao`,
       `s`.`dataHoraInicio`           AS `dataHoraInicio`,
       `s`.`dataHoraAgendada`         AS `dataHoraAgendada`,
       `s`.`estado`                   AS `estado`,
       `s`.`localidade`               AS `localidade`,
       `p`.`iDPaciente`               AS `iDPaciente`,
       `p`.`nome`                     AS `nomePaciente`,
       `p`.`pesoAtual`                AS `pesoAtual`,
       `p`.`raca`                     AS `raca`,
       `c`.`nome`                     AS `nomeCliente`,
       `c`.`NIF`                      AS `NIF`,
       (case
            when (`co`.`iDServico` is not null) then 'Consulta'
            when (`ci`.`iDServico` is not null) then 'Cirurgia'
            when (`v`.`iDServico` is not null) then 'Vacinação'
            when (`d`.`iDServico` is not null) then 'Desparasitacao'
            when (`t`.`iDServico` is not null) then 'Tratamento'
            when (`e`.`iDServico` is not null) then 'Exame'
            else 'Serviço Geral' end) AS `tipoServico`
from ((((((((`vetcare`.`servicomedicoagendamento` `s` join `vetcare`.`paciente` `p`
             on ((`s`.`iDPaciente` = `p`.`iDPaciente`))) join `vetcare`.`cliente` `c`
            on ((`p`.`NIF` = `c`.`NIF`))) left join `vetcare`.`consulta` `co`
           on ((`s`.`iDServico` = `co`.`iDServico`))) left join `vetcare`.`cirurgia` `ci`
          on ((`s`.`iDServico` = `ci`.`iDServico`))) left join `vetcare`.`vacinacao` `v`
         on ((`s`.`iDServico` = `v`.`iDServico`))) left join `vetcare`.`desparasitacao` `d`
        on ((`s`.`iDServico` = `d`.`iDServico`))) left join `vetcare`.`tratamentoterapeutico` `t`
       on ((`s`.`iDServico` = `t`.`iDServico`))) left join `vetcare`.`exame` `e`
      on ((`s`.`iDServico` = `e`.`iDServico`)))
order by `s`.`dataHoraAgendada` desc;

