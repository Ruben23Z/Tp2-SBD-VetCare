create definer = root@localhost view agenda_clinica as
select `s`.`dataHoraAgendada` AS `dataHoraAgendada`,
       `s`.`descricao`        AS `descricao`,
       `p`.`nome`             AS `paciente`,
       `c`.`nome`             AS `cliente`,
       `s`.`localidade`       AS `localidade`,
       `s`.`estado`           AS `estado`
from ((`vetcare`.`servicomedicoagendamento` `s` join `vetcare`.`paciente` `p`
       on ((`s`.`iDPaciente` = `p`.`iDPaciente`))) join `vetcare`.`cliente` `c` on ((`p`.`NIF` = `c`.`NIF`)))
order by `s`.`dataHoraAgendada`;

