create definer = root@localhost view proximas_vacinacoes as
select `v`.`iDServico`    AS `iDServico`,
       `p`.`nome`         AS `nomePaciente`,
       `v`.`fabricante`   AS `fabricante`,
       `v`.`dose`         AS `dose`,
       `v`.`dataValidade` AS `dataValidade`,
       `v`.`dataReforco`  AS `dataReforco`
from ((`vetcare`.`vacinacao` `v` join `vetcare`.`servicomedicoagendamento` `s`
       on ((`v`.`iDServico` = `s`.`iDServico`))) join `vetcare`.`paciente` `p`
      on ((`s`.`iDPaciente` = `p`.`iDPaciente`)))
where (`v`.`dataReforco` >= curdate())
order by `v`.`dataReforco`;

